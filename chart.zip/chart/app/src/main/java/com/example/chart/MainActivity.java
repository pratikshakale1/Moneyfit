package com.example.chart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String url="https://drive.google.com/file/d/1kdNeZF3oQr7aXwHbDyfGpSk1XgvGZ00c/view?usp=sharing";
    ArrayList valueset1=new ArrayList();
    ArrayList valueset2=new ArrayList();
    ArrayList dates=new ArrayList();
    ArrayList dataSets = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BarChart chart = (BarChart) findViewById(R.id.barChart);


        try
        {

            JSONObject jsonobject = new JSONObject(loadJSONFromAsset());
            JSONArray jarray = (JSONArray) jsonobject.getJSONArray("data");
            for(int i=0;i<jarray.length();i++)
            {
                JSONObject jb =(JSONObject) jarray.get(i);
                String date = jb.getString("date");
                int iiv = jb.getInt("investment_invest_value");
                int icv = jb.getInt("investment_current_value");

                BarEntry v1e1 = new BarEntry(iiv, i); // Jan
                valueset1.add(v1e1);
                BarEntry v2e1 = new BarEntry(icv, i); // Jan
                valueset2.add(v2e1);

                dates.add(date);
                Log.d("fetchData",date+" "+iiv+" "+icv);
            }

            BarDataSet barDataSet1 = new BarDataSet(valueset1, "investment invest value");
            barDataSet1.setColor(Color.rgb(0, 105, 150));
            BarDataSet barDataSet2 = new BarDataSet(valueset2, "investment current value");
            barDataSet2.setColor(Color.rgb(120, 155, 150));

            dataSets.add(barDataSet1);
            dataSets.add(barDataSet2);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        BarData data = new BarData(dates, dataSets);
        chart.setData(data);
        chart.setDescription("My Chart");
        chart.animateXY(2000, 2000);
        chart.invalidate();


    }





    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = getApplicationContext().getAssets().open("bonus.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }
}